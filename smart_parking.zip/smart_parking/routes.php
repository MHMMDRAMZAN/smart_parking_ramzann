<?php
require_once __DIR__ . '/app/controllers/ParkingController.php';

$c = new ParkingController();

if (!isset($_GET['action'])) {
    $c->index();
} else if ($_GET['action'] == 'buka') {
    $c->buka();
}