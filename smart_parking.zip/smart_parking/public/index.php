<?php
session_start();

// ================= REQUIRE =================
require_once __DIR__ . '/../app/controllers/ParkingController.php';
require_once __DIR__ . '/../app/controllers/AuthController.php';

// ================= AMBIL ACTION =================
$action = $_GET['action'] ?? '';

// ================= AUTH CONTROLLER =================
$auth = new AuthController();

// ================= PROTEK LOGIN =================
if (!isset($_SESSION['login']) && $action != 'login') {
    header("Location: ?action=login");
    exit;
}

// ================= ROUTING =================
switch ($action) {

    case 'login':
        $auth->login();
        break;

    case 'logout':
        $auth->logout();
        break;

    case 'buka':
        $controller = new ParkingController();
        $controller->buka();
        break;

    default:
        $controller = new ParkingController();
        $controller->index();
        break;
}