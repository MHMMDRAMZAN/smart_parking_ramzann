<?php
require_once __DIR__ . '/../config/database.php';

$id = $_GET['id'] ?? 0;

$data = $conn->query("SELECT * FROM transactions WHERE id=$id")->fetch_assoc();

if (!$data) {
    die("Data tidak ditemukan");
}

$textQR = "Terima kasih sudah parkir di sini";
$qr = urlencode($textQR);
?>

<!DOCTYPE html>
<html>
<head>
<title>Struk Parkir</title>

<style>
body {
    background: #0f172a;
    font-family: monospace;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.struk {
    background: #020617;
    color: white;
    padding: 30px;
    border-radius: 16px;
    width: 320px;
    text-align: center;
    border: 1px dashed #334155;
}

.line {
    border-top: 1px dashed #64748b;
    margin: 15px 0;
}

.btn {
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
}

button {
    padding: 10px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

.back { background: gray; }
.print { background: limegreen; }

@media print {
    .btn { display: none; }
    body { background: white; }
    .struk { color: black; border: none; }
}
</style>

</head>
<body>

<div class="struk">

<h2>SMART PARKING</h2>

<div class="line"></div>

<p>ID : <?= $data['card_id'] ?></p>
<p>Masuk : <?= $data['checkin_time'] ?></p>
<p>Keluar : <?= $data['checkout_time'] ?></p>
<p>Durasi : <?= $data['duration'] ?> jam</p>

<div class="line"></div>

<h3>Total: Rp <?= number_format($data['fee']) ?></h3>

<br>

<?php 
$textQR = "Terima kasih sudah parkir";
$qr = urlencode($textQR);
?>

<img src="https://quickchart.io/qr?text=<?= $qr ?>&size=150">

<div class="line"></div>

<p>Terima Kasih</p>

<div class="btn">
    <button class="back" onclick="history.back()">Kembali</button>
    <button class="print" onclick="window.print()">Cetak</button>
</div>

</div>

</body>
</html>