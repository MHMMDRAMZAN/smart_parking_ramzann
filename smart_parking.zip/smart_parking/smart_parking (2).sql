-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2026 at 05:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_parking`
--

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `card_id` varchar(50) DEFAULT NULL,
  `checkin_time` datetime DEFAULT NULL,
  `checkout_time` datetime DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `fee` int(11) DEFAULT NULL,
  `status` enum('IN','OUT','DONE') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `card_id`, `checkin_time`, `checkout_time`, `duration`, `fee`, `status`) VALUES
(1, '123', '2026-04-04 19:23:38', '2026-04-04 19:24:52', -4, -8000, 'DONE'),
(2, '123', '2026-04-04 19:41:39', '2026-04-04 19:42:19', -4, -8000, 'DONE'),
(3, '123', '2026-04-04 19:47:32', '2026-04-04 19:47:38', -4, -8000, 'DONE'),
(4, '123', '2026-04-04 19:49:43', '2026-04-04 19:49:48', -4, -8000, 'DONE'),
(5, '123', '2026-04-04 19:51:01', '2026-04-04 19:51:05', -4, -8000, 'DONE'),
(6, '123', '2026-04-04 19:52:22', '2026-04-04 19:52:29', -4, -8000, 'DONE'),
(7, '123', '2026-04-04 19:54:38', '2026-04-04 19:54:43', -4, -8000, 'DONE'),
(8, '123', '2026-04-04 19:55:11', '2026-04-04 19:55:15', -4, -8000, 'DONE'),
(9, '123', '2026-04-04 20:02:21', '2026-04-04 20:02:57', 1, 2000, 'DONE'),
(10, '123', '2026-04-04 20:15:40', '2026-04-04 20:21:03', 1, 2000, 'DONE'),
(11, '123', '2026-04-04 20:30:18', '2026-04-04 20:30:37', 1, 2000, 'DONE'),
(12, '1234', '2026-04-04 20:54:49', '2026-04-04 20:55:16', 1, 2000, 'DONE'),
(13, '1234', '2026-04-04 20:55:45', '2026-04-04 21:02:06', 1, 2000, 'DONE'),
(14, '1234', '2026-04-04 21:47:02', '2026-04-04 21:47:14', 1, 2000, 'DONE'),
(15, '1234', '2026-04-04 21:49:01', '2026-04-06 21:26:04', 48, 96000, 'DONE'),
(16, '1234', '2026-04-06 21:27:57', '2026-04-06 21:29:00', 1, 2000, 'DONE'),
(17, '1234', '2026-04-06 21:36:41', '2026-04-06 21:36:52', 1, 2000, 'DONE'),
(18, '1234', '2026-04-06 21:40:11', '2026-04-06 21:40:21', 1, 2000, 'DONE'),
(19, '1234', '2026-04-06 21:40:35', '2026-04-06 21:43:13', 1, 2000, 'OUT'),
(20, '1234', '2026-04-06 21:48:02', '2026-04-06 21:48:15', 1, 2000, 'DONE'),
(21, '1234', '2026-04-06 21:52:15', '2026-04-06 22:08:46', 1, 2000, 'DONE'),
(22, '1234', '2026-04-06 22:09:05', '2026-04-06 22:09:09', 1, 2000, 'DONE'),
(23, '1234', '2026-04-06 22:10:39', NULL, NULL, NULL, 'IN');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'petugas', '827ccb0eea8a706c4c34a16891f84e7b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
