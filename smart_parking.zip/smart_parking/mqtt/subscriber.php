<?php
require_once __DIR__ . '/phpMQTT.php';
require_once __DIR__ . '/../app/models/Parking.php';

use Bluerhinos\phpMQTT;

$server = "broker.hivemq.com";
$port = 1883;
$client_id = "PHPSubscriber-" . rand();

$mqtt = new phpMQTT($server, $port, $client_id);

if (!$mqtt->connect(true, NULL)) {
    exit("Gagal konek MQTT\n");
}

echo "Subscriber aktif...\n";

// ================= TOPIC =================
$topics['parking/ramzan1/entry/rfid'] = ['qos' => 0, 'function' => 'procmsg'];
$topics['parking/ramzan1/exit/rfid']  = ['qos' => 0, 'function' => 'procmsg'];

$mqtt->subscribe($topics, 0);

// ================= LOOP =================
while ($mqtt->proc()) {
}

$mqtt->close();

// ================= FUNCTION =================
function procmsg($topic, $msg) {

    // 🔥 bersihkan data
    $topic = trim($topic);
    $msg   = trim($msg);

    echo "====================\n";
    echo "TOPIC: $topic\n";
    echo "DATA : $msg\n";
    echo "====================\n";

    // ================= ENTRY =================
    if ($topic === "parking/ramzan1/entry/rfid") {

        echo "➡ ENTRY TERDETEKSI\n";

        $result = Parking::checkIn($msg);

        if ($result) {

            echo "✅ MASUK DB\n";

            // 🔥 buka palang ENTRY
            exec('"C:\\Program Files\\mosquitto\\mosquitto_pub.exe" -h broker.hivemq.com -t parking/ramzan1/entry/servo -m OPEN');

            exec('"C:\\Program Files\\mosquitto\\mosquitto_pub.exe" -h broker.hivemq.com -t parking/ramzan1/lcd -m "Selamat Datang|Silakan Masuk"');   
            echo "🚀 ENTRY → PALANG DIBUKA\n";

        } else {
            echo "⚠ SUDAH ADA / GAGAL\n";
        }
    }

    // ================= EXIT =================
    if ($topic === "parking/ramzan1/exit/rfid") {

        echo "⬅ EXIT TERDETEKSI\n";

        $result = Parking::checkOut($msg);

        if ($result) {
            echo "✅ PINDAH KE OUT\n";
        } else {
            echo "⚠ DATA TIDAK ADA\n";
        }
    }
}