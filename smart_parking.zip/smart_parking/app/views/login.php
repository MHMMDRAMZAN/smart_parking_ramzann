<!DOCTYPE html>
<html>
<head>
    <title>Login - Smart Parking</title>

    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0f172a, #1e3a8a);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: #1e293b;
            padding: 35px;
            border-radius: 15px;
            width: 320px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        .title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 5px;
            color: #60a5fa;
        }

        .subtitle {
            font-size: 13px;
            color: #94a3b8;
            margin-bottom: 20px;
        }

        label {
            font-size: 13px;
            color: #cbd5f5;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #334155;
            background: #0f172a;
            color: white;
            outline: none;
        }

        input:focus {
            border: 1px solid #2563eb;
        }

        button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(45deg, #2563eb, #1e3a8a);
            border: none;
            color: white;
            border-radius: 10px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #1d4ed8;
        }

        .error {
            background: #1e293b;
            border: 1px solid #ef4444;
            color: #ef4444;
            padding: 8px;
            border-radius: 8px;
            margin-bottom: 10px;
            font-size: 13px;
        }

        /* 🔥 animasi */
        .login-box {
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

    </style>
</head>

<body>

<div class="login-box">

    <div class="title">Smart Parking</div>
    <div class="subtitle">Masuk ke sistem</div>

    <?php if(isset($error)): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>

</div>

</body>
</html>