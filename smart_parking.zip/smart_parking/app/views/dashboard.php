<?php include 'layout/header.php'; ?>

<div class="container">

<h2 class="title">Dashboard Petugas</h2>

<style>
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #0f172a;
    color: #e2e8f0;
}

.title {
    margin-bottom: 20px;
    color: #60a5fa;
}

.flex {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.card {
    background: #1e293b;
    padding: 20px;
    border-radius: 12px;
    flex: 1;
    box-shadow: 0 4px 15px rgba(0,0,0,0.5);
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

.card h2 {
    margin-top: 10px;
    color: #60a5fa;
}

.table-box {
    background: #1e293b;
    padding: 20px;
    border-radius: 12px;
    margin-top: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.4);
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #2563eb;
    color: white;
}

td, th {
    padding: 10px;
    text-align: center;
    border: 1px solid #334155;
}

tr:nth-child(even) {
    background: #0f172a;
}

h3 {
    margin-bottom: 10px;
    background: #2563eb;
    color: white;
    padding: 10px;
    border-radius: 6px;
}

/* BUTTON */
a.btn {
    background: #2563eb;
    color: white;
    padding: 6px 12px;
    text-decoration: none;
    border-radius: 6px;
}

a.btn:hover {
    background: #1d4ed8;
}

/* PRINT BUTTON */
.btn-print {
    color: #22c55e;
    font-weight: 600;
    text-decoration: none;
    padding: 6px 12px;
    border: 1px solid #22c55e;
    border-radius: 6px;
    display: inline-block;
    margin-top: 5px;
}

.btn-print:hover {
    background: #22c55e;
    color: black;
}
</style>

<!-- CARD -->
<div class="flex">
    <div class="card">
        Kendaraan Aktif
        <h2><?= $in->num_rows ?></h2>
    </div>

    <div class="card">
        Transaksi Hari Ini
        <h2><?= $done->num_rows ?></h2>
    </div>

    <div class="card">
        Pendapatan
        <h2>
        Rp<?php 
        $total = 0;
        $dataTotal = Parking::get('DONE');
        while($d = $dataTotal->fetch_assoc()){
            $total += $d['fee'];
        }
        echo number_format($total);
        ?>
        </h2>
    </div>
</div>

<!-- CHECK IN -->
<div class="table-box">
<h3>Kendaraan Masuk (Check-In)</h3>

<table>
<tr>
    <th>No</th>
    <th>Card ID</th>
    <th>Waktu Masuk</th>
    <th>Status</th>
</tr>

<?php $no = 1; ?>
<?php while($d = $in->fetch_assoc()): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= $d['card_id'] ?></td>
    <td><?= $d['checkin_time'] ?></td>
    <td><?= $d['status'] ?></td>
</tr>
<?php endwhile; ?>

<?php if($in->num_rows == 0): ?>
<tr><td colspan="4">Belum ada kendaraan masuk</td></tr>
<?php endif; ?>

</table>
</div>

<!-- CHECK OUT -->
<div class="table-box">
<h3>Kendaraan Keluar (Check-Out)</h3>

<table>
<tr>
    <th>No</th>
    <th>Card ID</th>
    <th>Masuk</th>
    <th>Keluar</th>
    <th>Durasi</th>
    <th>Biaya</th>
    <th>Aksi</th>
</tr>

<?php $no = 1; ?>
<?php while($d = $out->fetch_assoc()): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= $d['card_id'] ?></td>
    <td><?= $d['checkin_time'] ?></td>
    <td><?= $d['checkout_time'] ?></td>
    <td><?= $d['duration'] ?> jam</td>
    <td>Rp<?= number_format($d['fee']) ?></td>
    <td>
        <a class="btn" href="?action=buka&id=<?= $d['id'] ?>">BUKA</a>
        <br>
    </td>
</tr>
<?php endwhile; ?>

<?php if($out->num_rows == 0): ?>
<tr><td colspan="7">Belum ada kendaraan keluar</td></tr>
<?php endif; ?>

</table>
</div>

<!-- LOG -->
<div class="table-box">
<h3>Log Aktivitas Parkir</h3>

<table>
<tr>
    <th>No</th>
    <th>Card ID</th>
    <th>Masuk</th>
    <th>Keluar</th>
    <th>Durasi</th>
    <th>Biaya</th>
    <th>Aksi</th>
</tr>

<?php $no = 1; ?>
<?php while($d = $done->fetch_assoc()): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= $d['card_id'] ?></td>
    <td><?= $d['checkin_time'] ?></td>
    <td><?= $d['checkout_time'] ?></td>
    <td><?= $d['duration'] ?> jam</td>
    <td>Rp<?= number_format($d['fee']) ?></td>
    <td>
        <a class="btn-print" href="struk.php?id=<?= $d['id'] ?>">Cetak Struk</a>
    </td>
</tr>
<?php endwhile; ?>

<?php if($done->num_rows == 0): ?>
<tr><td colspan="7">Belum ada riwayat</td></tr>
<?php endif; ?>

</table>
</div>

</div>

<?php include 'layout/footer.php'; ?>