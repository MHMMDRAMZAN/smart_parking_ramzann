<style>
.footer {
    margin-top: 30px;
    padding: 15px;
    text-align: left;
    background: #0f4af9;
    color: #000305;
    font-size: 14px;
    border-top: 2px solid #ffd6e0;
}
</style>

<div class="footer">
    © <?= date('Y') ?> Smart Parking System | By Ramzan
</div>

</body>
</html>