<style>
.sidebar {
    width: 200px;
    background: #2c3e50;
    color: white;
    height: 100vh;
    padding: 20px;
}
.sidebar a {
    display: block;
    color: white;
    margin: 10px 0;
    text-decoration: none;
}
</style>

<div class="sidebar">
    <h3>Smart Parking</h3>
    <a href="#">Dashboard</a>
    <a href="#">Rekap</a>
    <a href="#">Logout</a>
</div>