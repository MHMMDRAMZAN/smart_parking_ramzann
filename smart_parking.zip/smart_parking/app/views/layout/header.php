
<!DOCTYPE html>
<html>
<head>
    <title>Smart Parking</title>
    <style>
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #0f172a;
    color: #e2e8f0;
}

/* HEADER */
.header {
    background: linear-gradient(45deg, #1e3a8a, #2563eb);
    padding: 18px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header h1 {
    margin: 0;
    font-size: 20px;
    font-weight: 600;
}

/* LOGOUT */
.logout {
    background: #0f172a;
    color: #60a5fa;
    padding: 8px 16px;
    border-radius: 8px;
    text-decoration: none;
    border: 1px solid #2563eb;
    transition: 0.3s;
}

.logout:hover {
    background: #2563eb;
    color: white;
}
</style>
</head>

<body>

<div class="header">
    <h1>Smart Parking</h1>

    <div class="header-right">
        <?php if(isset($_SESSION['login'])): ?>
            <a href="?action=logout" class="logout">Logout</a>
        <?php endif; ?>
    </div>
</div>