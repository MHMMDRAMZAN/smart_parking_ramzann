<?php
require_once __DIR__ . '/../models/User.php';

class AuthController {

    public function login() {

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $username = $_POST['username'];
            $password = $_POST['password'];

            if (User::login($username, $password)) {

                session_start();
                $_SESSION['login'] = true;

                header("Location: /smart_parking/public/");
            } else {
                $error = "Login gagal!";
            }
        }

        include __DIR__ . '/../views/login.php';
    }

    public function logout() {
        session_start();
        session_destroy();
        header("Location: /smart_parking/public/?action=login");
    }
}