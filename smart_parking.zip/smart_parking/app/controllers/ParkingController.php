<?php
require_once __DIR__ . '/../models/Parking.php';

class ParkingController {

    public function index() {
        $in = Parking::get('IN');
        $out = Parking::get('OUT');
        $done = Parking::get('DONE');

        include __DIR__ . '/../views/dashboard.php';
    }

    public function buka() {
        $id = $_GET['id'];

        Parking::selesai($id);

        // 🔥 FULL PATH (WAJIB)
        exec('"C:\\Program Files\\mosquitto\\mosquitto_pub.exe" -h broker.hivemq.com -t parking/ramzan1/exit/servo -m OPEN');

        exec('"C:\\Program Files\\mosquitto\\mosquitto_pub.exe" -h broker.hivemq.com -t parking/ramzan1/lcd -m "Terima Kasih|Silakan Jalan"');

        header("Location: /smart_parking/public/");
    }
}