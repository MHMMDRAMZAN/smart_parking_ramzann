<?php
require_once __DIR__ . '/../../config/database.php';

class Parking {

    // 🔹 Tarif per jam
    private static $tarif_per_jam = 2000;

    // ========================
    // CHECK IN
    // ========================
    public static function checkIn($card_id) {
        global $conn;

        // Cek apakah masih parkir
        $cek = $conn->query("SELECT id FROM transactions 
                             WHERE card_id='$card_id' AND status='IN'");

        if ($cek->num_rows > 0) {
            return false;
        }

        // Insert data
        $conn->query("INSERT INTO transactions 
            (card_id, checkin_time, status) 
            VALUES ('$card_id', NOW(), 'IN')");

        return true;
    }

    // ========================
    // CHECK OUT (FIX TOTAL)
    // ========================
    public static function checkOut($card_id) {
        global $conn;

        // Ambil data IN
        $data = $conn->query("SELECT * FROM transactions 
                              WHERE card_id='$card_id' AND status='IN'");

        if ($data->num_rows == 0) {
            return false;
        }

        $row = $data->fetch_assoc();
        $id = $row['id'];
   

        // 🔥 HITUNG DURASI DARI MYSQL (ANTI NGACO)
        $q = $conn->query("
            SELECT TIMESTAMPDIFF(SECOND, checkin_time, NOW()) AS selisih
            FROM transactions
            WHERE id = $id
        ");

        $hasil = $q->fetch_assoc();
        $selisih = $hasil['selisih'];

        // Antisipasi kalau minus
        if ($selisih < 0) {
            $selisih = 0;
        }

        // Konversi ke jam
        $durasi = ceil($selisih / 3600);

        // Minimal 1 jam
        if ($durasi < 1) {
            $durasi = 1;
        }

        // Hitung biaya
        $biaya = $durasi * self::$tarif_per_jam;

        // Update data
        $conn->query("UPDATE transactions SET
            checkout_time = NOW(),
            duration = $durasi,
            fee = $biaya,
            status = 'OUT'
            WHERE id = $id");

        return true;
    }

    // ========================
    // SELESAI
    // ========================
    public static function selesai($id) {
        global $conn;

        $conn->query("UPDATE transactions 
                      SET status='DONE' 
                      WHERE id=$id");
    }

    // ========================
    // GET DATA
    // ========================
    public static function get($status) {
        global $conn;

        return $conn->query("SELECT * FROM transactions 
                            WHERE status='$status' 
                            ORDER BY id DESC");
    }
}