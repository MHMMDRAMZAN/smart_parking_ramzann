<?php
require_once __DIR__ . '/../../config/database.php';

class User {

    public static function login($username, $password) {
        global $conn;

        $password = md5($password);

        $data = $conn->query("SELECT * FROM users 
                              WHERE username='$username' 
                              AND password='$password'");

        return $data->num_rows > 0;
    }
}