<?php
define("MQTT_HOST", "localhost");
define("MQTT_PORT", 1883);
define("MQTT_CLIENT_ID", "phpMQTT-" . rand());