<?php
date_default_timezone_set('Asia/Jakarta');

$conn = new mysqli("localhost", "root", "", "smart_parking");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// set timezone MySQL
$conn->query("SET time_zone = '+07:00'");